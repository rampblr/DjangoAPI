from django.shortcuts import render
# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import *
from .serializers import *
from rest_framework import viewsets
import pandas as pd
import json
# Create your views here.

		
class MarkListApiView(APIView):
	def get(self,request):
		#markList=Mark.objects.all().values()
		markList	= pd.DataFrame(list(Mark.objects.all().values()))
		stuList		= pd.DataFrame(list(Student.objects.all().values()))
		markList.convert_dtypes().dtypes
		#print(markList.loc[1:6])
		
		markList.loc[:, 'total'] = markList.iloc[:, [1,2,3,4,5]].sum(numeric_only=True, axis=1)
		markList.loc[:, 'average'] = markList.iloc[:, [1,2,3,4,5]].mean(numeric_only=True, axis=1)
		markList = markList.merge(stuList, on="stu_id",  how = 'inner')
		#print(markList)
		return Response({"Message":"List of Students Marks", "Mark Details":json.loads(markList.to_json(orient='records'))})
		
class StudentViewSet(viewsets.ModelViewSet):
	queryset = Student.objects.all()
	serializer_class=StudentSerializer
	
class MarkViewSet(viewsets.ModelViewSet):
	queryset = Mark.objects.all()
	serializer_class=MarkSerializer