from django.db import models

# Create your models here.
class Student(models.Model):
	stu_id=models.IntegerField(primary_key=True)
	first_name=models.CharField(max_length=20)
	last_name=models.CharField(max_length=20,null=True,blank=True)
	dob=models.DateField(null=True,blank=True)

class Mark(models.Model):
	stu_id	=	models.IntegerField(primary_key=True)
	Sub1 	=	models.IntegerField(primary_key=False)
	Sub2 	=	models.IntegerField(primary_key=False)
	Sub3 	=	models.IntegerField(primary_key=False)
	Sub4 	=	models.IntegerField(primary_key=False)
	Sub5 	=	models.IntegerField(primary_key=False)
	